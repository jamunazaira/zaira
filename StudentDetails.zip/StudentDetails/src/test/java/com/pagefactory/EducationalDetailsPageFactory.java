package com.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EducationalDetailsPageFactory {
	
WebDriver Driver;
	
	@FindBy(name="graduation")
	@CacheLookup
	WebElement graduation;

	@FindBy(id="txtPercentage")
	@CacheLookup
	WebElement percentage;

	@FindBy(id="txtPassYear")
	@CacheLookup
	WebElement passYear ;


	@FindBy(id="txtProjectName")
	@CacheLookup
	WebElement projectName;
	
	@FindBy(xpath="//input[@value='Other']")
	@CacheLookup
	WebElement technology;
	
	@FindBy(xpath="//input[@value='Java']")
	@CacheLookup
	WebElement techJava;
	

	@FindBy(id="txtOtherTechs")
	@CacheLookup
	WebElement otherTechnologies;
	
	

	@FindBy(id="btnRegister")
	@CacheLookup
	WebElement RegisterBtn;

	public WebDriver getDriver() {
		return Driver;
	}

	public void setDriver(WebDriver driver) {
		Driver = driver;
	}

	public WebElement getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public WebElement getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public WebElement getPassYear() {
		return passYear;
	}

	public void setPassYear(String passYear) {
		this.passYear.sendKeys(passYear);
	}

	public WebElement getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public WebElement getTechnology() {
		return technology;
	}

	
	public void setTechnology() {
		this.technology.click();
		}

	public WebElement getTechJava() {
		return techJava;
	}

	public void setTechJava() {
		this.techJava.click();
	}
	
	public WebElement getOtherTechnologies() {
		return otherTechnologies;
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}

	public WebElement getRegisterBtn() {
		return RegisterBtn;
	}

	public void setRegisterBtn() {
		RegisterBtn.click();
	}

	public EducationalDetailsPageFactory(WebDriver driver) {
		super();
		Driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	
	
}
