package com.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PersonalDetailsPageFactory {
	
	WebDriver Driver;
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement fname;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lname;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phNo;
	
	@FindBy(id="txtAddress1")
	@CacheLookup
	WebElement addLine1;
	
	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement addLine2;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(xpath="//a[@onclick='personalDetailsFrmValidation()']")
	@CacheLookup
	WebElement nextLink;

	public WebDriver getDriver() {
		return Driver;
	}

	public void setDriver(WebDriver driver) {
		Driver = driver;
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getPhNo() {
		return phNo;
	}

	public void setPhNo(String phNo) {
		this.phNo.sendKeys(phNo);
	}

	public WebElement getAddLine1() {
		return addLine1;
	}

	public void setAddLine1(String addLine1) {
		this.addLine1.sendKeys(addLine1);
	}

	public WebElement getAddLine2() {
		return addLine2;
	}

	public void setAddLine2(String addLine2) {
		this.addLine2.sendKeys(addLine2);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getNextLink() {
		return nextLink;
	}

	public void setNextLink() {
		this.nextLink.click();
	}

	public PersonalDetailsPageFactory(WebDriver driver) {
		super();
		Driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	

}
